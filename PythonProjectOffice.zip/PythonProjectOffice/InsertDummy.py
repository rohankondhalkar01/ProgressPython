import sqlite3
import random
from datetime import datetime

from database import DB_PATH, create_database

# Ensure DB exists
create_database()


first_names = [
"Rohan","Amit","Sneha","Pooja","Rahul","Neha","Vikas",
"Anjali","Karan","Priya","Saurabh","Deepak","Arjun",
"Nisha","Manish","Kavita","Harsh","Komal","Aditya",
"Ritika","Sameer","Isha","Nikhil","Sakshi","Omkar",
"Tejas","Tanvi","Akash","Ritesh","Madhuri"
]

last_names = [
"Sharma","Patil","Desai","Kulkarni","Joshi","Iyer",
"Rao","Mehta","Singh","Nair","Verma","Gupta","Reddy",
"Patel","Chavan","Shetty","Tiwari","Jadhav","Nambiar",
"Bose","Khan","Malhotra","Pawar","More","Salvi",
"Naik","Shinde","Das","Sawant","Kale"
]

courses = ["MCA", "MBA", "BBA"]
status = ["Active", "Dropped", "Completed"]
categories = ["General", "OBC", "SC", "ST"]


def random_date():
    year = random.randint(2001, 2005)
    month = random.randint(1, 12)
    day = random.randint(1, 28)
    return f"{day}-{month}-{year}"


def insert_data():

    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()

    # ===== DELETE OLD VALUES =====
    c.execute("DELETE FROM student")

    # ===== RESET AUTOINCREMENT TO START FROM 1 =====
    c.execute("DELETE FROM sqlite_sequence WHERE name='student'")

    conn.commit()

    print("🗑 Old data deleted & ID reset to 1")

    for i in range(60):

        fn = random.choice(first_names)
        ln = random.choice(last_names)

        email = f"{fn.lower()}.{ln.lower()}@mitwpu.edu.in"

        phone = "9" + str(random.randint(100000000, 999999999))

        c.execute("""
        INSERT INTO student(
        first_name,last_name,gender,date_of_birth,age,
        email,phone_number,enrollment_date,course_id,
        academic_year,semester,category,nationality,current_status)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """,
        (
            fn,
            ln,
            random.choice(["Male","Female"]),
            random_date(),
            random.randint(18,24),

            email,
            phone,

            datetime.today().strftime("%d-%m-%Y"),

            random.choice(courses),

            "2024-2026",

            random.choice(["1","2","3","4"]),
            random.choice(categories),

            "Indian",

            random.choice(status)
        ))

    conn.commit()
    conn.close()

    print("✅ Fresh MITWPU Dummy Students Inserted (ID from 1)")


insert_data()
