import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3

from database import DB_PATH


# ===== LOAD DATA =====
def load_data():

    for i in tree.get_children():
        tree.delete(i)

    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()

    c.execute("SELECT * FROM attendance")

    for row in c.fetchall():
        tree.insert("", "end", values=row)

    conn.close()


# ===== ANALYZE ATTENDANCE =====
def analyze():

    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()

    # Average attendance
    c.execute("SELECT AVG(attendance_percentage) FROM attendance")
    avg = c.fetchone()[0]

    # Defaulters (<75%)
    c.execute("SELECT COUNT(*) FROM attendance WHERE attendance_percentage < 75")
    defaulters = c.fetchone()[0]

    # Total students
    c.execute("SELECT COUNT(*) FROM attendance")
    total = c.fetchone()[0]

    conn.close()

    lbl_avg.config(text=f"Average Attendance : {round(avg,2) if avg else 0}%")
    lbl_def.config(text=f"Defaulters (<75%) : {defaulters}")
    lbl_total.config(text=f"Total Records : {total}")


# ===== MAIN SCREEN =====
def attendance_screen():

    global tree, lbl_avg, lbl_def, lbl_total

    top = tk.Tk()
    top.title("Attendance Monitoring")

    # FULL SCREEN
    top.attributes('-fullscreen', True)
    top.bind("<Escape>", lambda e: top.attributes('-fullscreen', False))

    ttk.Label(top,
        text="Attendance Monitoring & Analysis",
        font=("Helvetica", 22, "bold")
    ).pack(pady=10)

    # ===== SUMMARY =====
    s = ttk.Frame(top, padding=10)
    s.pack()

    lbl_avg = ttk.Label(s, text="Average Attendance : 0%", font=("Arial", 14))
    lbl_avg.grid(row=0, column=0, padx=20)

    lbl_def = ttk.Label(s, text="Defaulters (<75%) : 0", font=("Arial", 14))
    lbl_def.grid(row=0, column=1, padx=20)

    lbl_total = ttk.Label(s, text="Total Records : 0", font=("Arial", 14))
    lbl_total.grid(row=0, column=2, padx=20)

    ttk.Button(top, text="Analyze", command=analyze).pack(pady=5)

    # ===== TABLE =====
    tree = ttk.Treeview(top,
        columns=(
        "id","student_id","course_id","semester",
        "total_classes","attended","percentage",
        "late","medical","unauthorized",
        "status","updated","trend","flag"),
        show="headings"
    )

    for col in tree["columns"]:
        tree.heading(col, text=col)

    tree.pack(fill="both", expand=True)

    ttk.Button(top, text="Refresh", command=load_data).pack(pady=5)
    ttk.Button(top, text="Back", command=top.destroy).pack(pady=5)

    load_data()
    top.mainloop()
