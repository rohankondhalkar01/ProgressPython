import tkinter as tk
from tkinter import ttk, messagebox

def open_main():

    top = tk.Tk()
    top.title("Dashboard")

    # ===== FULL SCREEN MODE =====
    top.attributes('-fullscreen', True)

    # Press ESC to exit full screen
    top.bind("<Escape>", lambda e: top.attributes('-fullscreen', False))

    top.configure(bg="#1e1e1e")

    style = ttk.Style()
    style.theme_use('clam')

    ttk.Label(top,
        text="Dropout Risk Prediction System – Dashboard",
        font=("Helvetica", 20, "bold")
    ).pack(pady=20)

    frame = ttk.Frame(top, padding=20)
    frame.pack()

    def student_profile():
        messagebox.showinfo("Module", "Student Profile")

    def student_profile():
        from StudentProfileScreen import student_profile_screen
        student_profile_screen()

    ttk.Button(frame,
               text="1. Student Profile Management",
               command=student_profile,
               width=40).pack(pady=6)

    # ===== FUTURE MODULES =====
    """
    ttk.Button(frame, text="2. Data Collection & Integration").pack()
    ttk.Button(frame, text="3. Academic Performance Analysis").pack()
    ttk.Button(frame, text="4. Attendance Monitoring").pack()
    ttk.Button(frame, text="5. Behavioral & Engagement Analysis").pack()
    ttk.Button(frame, text="6. Financial Risk Analysis").pack()
    ttk.Button(frame, text="7. ML-Based Dropout Prediction").pack()
    ttk.Button(frame, text="8. Risk Scoring & Categorization").pack()
    ttk.Button(frame, text="9. Intervention & Counseling").pack()
    ttk.Button(frame, text="10. Analytics Dashboard").pack()
    """

    ttk.Button(top, text="Exit", command=top.quit).pack(pady=10)

    top.mainloop()
