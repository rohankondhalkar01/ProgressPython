import sqlite3
import random
from datetime import datetime

from database import DB_PATH, create_database

# Ensure DB exists
create_database()


def insert_attendance():

    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()

    # ----- Clear old -----
    c.execute("DELETE FROM attendance")
    c.execute("DELETE FROM sqlite_sequence WHERE name='attendance'")
    conn.commit()

    # ----- Get students -----
    c.execute("SELECT student_id, course_id FROM student")
    students = c.fetchall()

    if not students:
        print("⚠ No students found! Insert students first.")
        return

    for s in students:

        student_id = s[0]
        course = s[1]

        for sem in ["1", "2", "3", "4"]:

            total = 100
            attended = random.randint(55, 98)

            percent = round((attended / total) * 100, 2)

            status = "Defaulter" if percent < 75 else "Regular"

            trend = random.choice(["Improving", "Stable", "Declining"])

            c.execute("""
            INSERT INTO attendance(
            student_id, course_id, semester,
            total_classes, classes_attended,
            attendance_percentage,
            late_attendance, medical_leave_days,
            unauthorized_absence,
            attendance_status,
            last_updated,
            attendance_trend,
            flagged
            )
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)
            """,
            (
                student_id,
                course,
                sem,
                total,
                attended,
                percent,
                random.randint(0,5),
                random.randint(0,3),
                random.randint(0,4),
                status,
                datetime.today().strftime("%d-%m-%Y"),
                trend,
                "Yes" if percent < 65 else "No"
            ))

    conn.commit()
    conn.close()

    print("✅ Attendance Dummy Data Generated Successfully")


insert_attendance()
