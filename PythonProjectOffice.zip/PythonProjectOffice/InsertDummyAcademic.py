import sqlite3
import random
from datetime import datetime

from database import DB_PATH, create_database

# Ensure DB exists
create_database()


def insert_academic_data():

    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()

    # ----- Clear old academic data -----
    c.execute("DELETE FROM academic_performance")
    c.execute("DELETE FROM sqlite_sequence WHERE name='academic_performance'")
    conn.commit()

    # ----- Get all students -----
    c.execute("SELECT student_id FROM student")
    students = c.fetchall()

    if not students:
        print("⚠ No students found! Insert students first.")
        return

    for s in students:
        student_id = s[0]

        # Create 4 semester records per student
        for sem in ["1", "2", "3", "4"]:

            gpa = round(random.uniform(5.0, 9.5), 2)

            # CGPA grows gradually
            cgpa = round(gpa - random.uniform(0, 0.8), 2)

            failed = random.choice([0, 0, 1, 0, 2])   # mostly 0
            attendance = random.randint(60, 98)

            internal = random.randint(20, 48)
            external = random.randint(25, 48)

            warning = "Yes" if failed > 0 or attendance < 65 else "No"

            improvement = random.choice(
                ["Improving", "Stable", "Declining"]
            )

            rank = random.randint(1, 120)

            c.execute("""
            INSERT INTO academic_performance(
            student_id,
            semester,
            GPA,
            CGPA,
            total_credits_registered,
            credits_earned,
            failed_subjects,
            attendance_percentage,
            internal_marks,
            external_marks,
            class_rank,
            improvement_status,
            academic_warning,
            evaluation_date
            )
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """,
            (
                student_id,
                sem,
                gpa,
                cgpa,
                24,
                24 - failed * 3,
                failed,
                attendance,
                internal,
                external,
                rank,
                improvement,
                warning,
                datetime.today().strftime("%d-%m-%Y")
            ))

    conn.commit()
    conn.close()

    print("✅ Academic Performance Dummy Data Generated Successfully")


insert_academic_data()
